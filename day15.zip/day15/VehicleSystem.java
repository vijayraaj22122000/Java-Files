package day15;

class Vehicle{
	public void startEngine() {
		System.out.println("Vehicle Engine started");
	}
}

class Car extends Vehicle{
	public void drive() {
		System.out.println("Car is driving......");
	}
}

class ElectricCar extends Car{
	public void chargeBattery() {
		System.out.println("Electric Car is charging.......");
	}
}

class Bike extends Vehicle{
	public void kickStart() {
		System.out.println("Bike is kick-started........");
	}
}

public class VehicleSystem {
	public static void main(String[] args) {
		Vehicle v1 = new Vehicle();
		v1.startEngine();
		
		Car c1 = new Car();
		c1.drive();
		
		ElectricCar e1 = new ElectricCar();
		e1.chargeBattery();
		
		Bike b1 = new Bike();
		b1.kickStart();
	}

}
