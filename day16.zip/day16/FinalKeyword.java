package day16;

class practice{
  final void display(final String name) {
	  System.out.println("h1 "+name);
}
}

public class FinalKeyword {
	public static void main(String[] args) {
		practice p1 = new practice();
		p1.display("Raj");

	}

}
