package day16;


class Animal{
	void eat() {
		System.out.println("This animal eats food.");
	}
}

class Dog extends Animal{
	void bark() {
		System.out.println("The dog barks");
	}
}



public class TestHierarchicalInheritance {

	public static void main(String[] args) {
		Dog a1 = new Dog();
		a1.bark();

	}

}
